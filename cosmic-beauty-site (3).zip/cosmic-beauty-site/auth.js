/* ============================================================
   Cosmic Beauty Spa — auth.js
   Shared sign-in bar + page guard for every page.

   Usage (already in your pages):
     CosmicAuth.injectAuthBar(allowedRoles, pageKey)
       allowedRoles: ['guest','esthetician'] for public pages,
                     ['esthetician'] for staff-only pages
       pageKey:      'home' | 'about' | 'shop' | 'dashboard' | 'inventory'

   Roles:
     guest        — anyone, signed in as a client or not signed in
     esthetician  — a signed-in account whose profile has is_admin = true

   The session itself is written by supabase-client.js (cbs_session).
   IMPORTANT: this file only controls what the page SHOWS. What data a
   person can actually read or change is enforced by the database's
   security rules, so a blocked page is a courtesy, not the lock.
   ============================================================ */

(function () {
  'use strict';

  const SESSION_KEY = 'cbs_session';

  const LINKS = {
    home:      'index.html',
    portal:    'client-portal.html',
    dashboard: 'esthetician-dashboard.html',
    inventory: 'inventory-manager.html',
    shop:      'bioelements-shop.html'
  };

  /* ── Session ─────────────────────────────────────────────── */
  function getSession() {
    if (window.CosmicAuthSession) return window.CosmicAuthSession;
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function getRole() {
    const s = getSession();
    return s && s.role === 'esthetician' ? 'esthetician' : 'guest';
  }

  function isSignedIn() {
    const s = getSession();
    return !!(s && (s.user || s.email));
  }

  function displayName(s) {
    if (!s) return '';
    const p = s.profile || {};
    return p.first_name || (s.name || '').split(' ')[0] || (s.email || '').split('@')[0] || '';
  }

  // Finds whichever Supabase client this page created (supabase-client.js
  // puts it on window; the inventory manager declares its own _sb).
  function getClient() {
    if (window._sb && window._sb.auth) return window._sb;
    try { if (typeof _sb !== 'undefined' && _sb && _sb.auth) return _sb; } catch (e) {}
    return null;
  }

  async function signOut() {
    try {
      if (typeof window.cbsLogout === 'function') {
        await window.cbsLogout();
      } else {
        const c = getClient();
        if (c) await c.auth.signOut();
      }
    } catch (e) { /* still clear locally below */ }
    try { localStorage.removeItem(SESSION_KEY); } catch (e) {}
    window.CosmicAuthSession = null;
    location.reload();
  }

  /* ── Styles (injected once) ──────────────────────────────── */
  function injectStyles() {
    if (document.getElementById('cab-styles')) return;
    const css = `
.cab-bar{position:fixed;left:18px;bottom:18px;z-index:9000;display:flex;align-items:center;gap:10px;flex-wrap:wrap;max-width:calc(100vw - 36px);
  padding:9px 14px;border-radius:100px;background:rgba(10,8,32,.92);border:1px solid rgba(168,85,247,.35);
  box-shadow:0 0 28px rgba(107,47,160,.35);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  font-family:'DM Sans',system-ui,sans-serif;font-size:12px;color:#e8d5ff;cursor:auto;}
.cab-bar *{cursor:auto;}
.cab-dot{width:7px;height:7px;border-radius:50%;background:#a855f7;box-shadow:0 0 10px #a855f7;flex-shrink:0;}
.cab-name strong{font-weight:600;color:#f5f0ff;}
.cab-role{font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:#a855f7;border:1px solid rgba(168,85,247,.35);padding:2px 8px;border-radius:100px;}
.cab-bar a,.cab-bar button{font:inherit;font-size:11px;letter-spacing:.06em;color:rgba(232,213,255,.75);text-decoration:none;background:none;border:none;padding:2px 4px;cursor:pointer;}
.cab-bar a:hover,.cab-bar button:hover{color:#a855f7;}
.cab-bar a.cab-here{color:#a855f7;pointer-events:none;}
.cab-sep{color:rgba(168,85,247,.35);}
.cab-lock{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;padding:24px;
  background:radial-gradient(ellipse at center,rgba(26,10,61,.97),rgba(3,6,18,.99));font-family:'DM Sans',system-ui,sans-serif;cursor:auto;}
.cab-lock *{cursor:auto;}
.cab-card{max-width:420px;width:100%;text-align:center;padding:40px 32px;border-radius:24px;background:rgba(18,10,45,.9);
  border:1px solid rgba(168,85,247,.3);box-shadow:0 0 60px rgba(107,47,160,.3);color:#e8d5ff;}
.cab-card .cab-icon{font-size:40px;margin-bottom:14px;}
.cab-card h2{font-family:'Cormorant Garamond',Georgia,serif;font-weight:300;font-size:30px;margin:0 0 10px;color:#f5f0ff;}
.cab-card p{font-size:14px;line-height:1.7;color:rgba(232,213,255,.6);margin:0 0 24px;}
.cab-btn{display:inline-block;margin:4px;padding:11px 24px;border-radius:100px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;cursor:pointer;}
.cab-btn-primary{background:linear-gradient(135deg,#7c3aed,#6b2fa0);color:#fff;box-shadow:0 0 20px rgba(124,58,237,.45);}
.cab-btn-ghost{color:#e8d5ff;border:1px solid rgba(168,85,247,.35);}
@media(max-width:640px){.cab-bar{left:10px;right:10px;bottom:10px;border-radius:18px;justify-content:center;}}
@media print{.cab-bar,.cab-lock{display:none!important;}}`;
    const style = document.createElement('style');
    style.id = 'cab-styles';
    style.textContent = css;
    document.head.appendChild(style);
  }

  function el(tag, attrs, text) {
    const n = document.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }

  /* ── Staff-only lock screen ──────────────────────────────── */
  function showLock() {
    if (document.getElementById('cab-lock')) return;
    const lock = el('div', { id: 'cab-lock', class: 'cab-lock', role: 'dialog', 'aria-modal': 'true' });
    const card = el('div', { class: 'cab-card' });
    card.appendChild(el('div', { class: 'cab-icon' }, '🔒'));
    card.appendChild(el('h2', null, 'Staff Only'));
    card.appendChild(el('p', null,
      'This page is for Cosmic Beauty Spa estheticians. Sign in on the esthetician dashboard, then come back here.'));
    card.appendChild(el('a', { class: 'cab-btn cab-btn-primary', href: LINKS.dashboard }, 'Esthetician Sign In'));
    card.appendChild(el('a', { class: 'cab-btn cab-btn-ghost', href: LINKS.home }, 'Back to Site'));
    lock.appendChild(card);
    document.body.appendChild(lock);
    document.documentElement.style.overflow = 'hidden';
  }

  function hideLock() {
    const l = document.getElementById('cab-lock');
    if (l) l.remove();
    document.documentElement.style.overflow = '';
  }

  /* ── Signed-in bar ───────────────────────────────────────── */
  function renderBar(pageKey) {
    const old = document.getElementById('cab-bar');
    if (old) old.remove();
    if (!isSignedIn()) return; // public visitors see the page untouched

    const s = getSession();
    const role = getRole();
    const bar = el('div', { id: 'cab-bar', class: 'cab-bar' });

    bar.appendChild(el('span', { class: 'cab-dot', 'aria-hidden': 'true' }));
    const name = el('span', { class: 'cab-name' });
    name.appendChild(document.createTextNode('Hi, '));
    name.appendChild(el('strong', null, displayName(s) || 'there'));
    bar.appendChild(name);
    if (role === 'esthetician') bar.appendChild(el('span', { class: 'cab-role' }, 'Esthetician'));
    bar.appendChild(el('span', { class: 'cab-sep', 'aria-hidden': 'true' }, '·'));

    const links = role === 'esthetician'
      ? [['dashboard', 'Dashboard'], ['inventory', 'Inventory'], ['shop', 'Shop']]
      : [['portal', 'My Portal'], ['shop', 'Shop']];
    for (const [key, label] of links) {
      const a = el('a', { href: LINKS[key] }, label);
      if (key === pageKey) a.className = 'cab-here';
      bar.appendChild(a);
    }

    const out = el('button', { type: 'button' }, 'Sign out');
    out.addEventListener('click', signOut);
    bar.appendChild(out);

    document.body.appendChild(bar);
  }

  /* ── Main entry point ────────────────────────────────────── */
  function apply(allowedRoles, pageKey) {
    const allowed = Array.isArray(allowedRoles) && allowedRoles.length ? allowedRoles : ['guest', 'esthetician'];
    const role = getRole();
    if (allowed.indexOf(role) === -1) {
      const bar = document.getElementById('cab-bar');
      if (bar) bar.remove();
      showLock();
      return false;
    }
    hideLock();
    renderBar(pageKey);
    return true;
  }

  function injectAuthBar(allowedRoles, pageKey) {
    const run = () => {
      injectStyles();
      const ok = apply(allowedRoles, pageKey);
      verifyWithServer(allowedRoles, pageKey);
      return ok;
    };
    if (document.body) return run();
    document.addEventListener('DOMContentLoaded', run, { once: true });
    return true;
  }

  // The saved session can go stale (expired, signed out elsewhere).
  // Double-check with Supabase and redraw if it has.
  let verifying = false;
  async function verifyWithServer(allowedRoles, pageKey) {
    if (verifying) return;
    const c = getClient();
    if (!c) return;
    verifying = true;
    try {
      const { data } = await c.auth.getSession();
      const live = data && data.session && data.session.user;
      const saved = getSession();
      if (!live && saved) {
        try { localStorage.removeItem(SESSION_KEY); } catch (e) {}
        window.CosmicAuthSession = null;
        apply(allowedRoles, pageKey);
      } else if (live && saved && saved.user && saved.user.id && saved.user.id !== live.id) {
        try { localStorage.removeItem(SESSION_KEY); } catch (e) {}
        window.CosmicAuthSession = null;
        apply(allowedRoles, pageKey);
      }
    } catch (e) { /* offline: keep what we have */ }
    finally { verifying = false; }
  }

  window.CosmicAuth = {
    injectAuthBar,
    getSession,
    getRole,
    isSignedIn,
    signOut,
    links: LINKS
  };
})();
